using BettingForHorseRace;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DesktopAppAboutBetting
{
    public partial class Form1 : Form
    {
        List<Sorsolas> sorsolasok = new List<Sorsolas>();
        List<Szam> szamok = new List<Szam>();
        public Form1()
        {
            InitializeComponent();
            //Task one
            List<Sorsolas> sorsolas_list = new List<Sorsolas>();
            string[] lines = File.ReadAllLines("fogadasok.txt");
            foreach (var item in lines)
            {
                string[] values = item.Split(';');
                Sorsolas sorsolas_object = new Sorsolas(values[0], values[1], values[2], values[3], values[4]);
                sorsolasok.Add(sorsolas_object);
            }

            //Task three

            //'user13' has the most betting, and it cost 11000.

            //Task four
            List<Szam> szamok = new List<Szam>();

            int min = int.MaxValue;
            int minimalWin = 0;
            foreach (var item in szamok)
            {
                if (min < item.win)
                {
                    min = item.win;
                    minimalWin = item.winner;
                }
            }
            Console.WriteLine(minimalWin);
            //The correct result is 25.

            //Task five
            int db = 0;
            for (int i = 1; i < 52; i++)
            {
                foreach (var item in sorsolas_list)
                {
                    if (i == "nyertes")
                    {
                        db++;
                    }
                }
                Szam szam_object = new Szam(winner, db);
                szamok.Add(szam_object);
                db = 0;
            }
            Console.WriteLine("db");
            //The 7th betting has the maximal prize.

            //Task six

            Sorsolas max_ertek_user = sorsolas_list[0];
            foreach (var item in sorsolas_list)
            {
                if (item.sum_win > max_win)
                {
                    max_win = item.sum_win;
                    max_ertek_user = item;
                }
                if (item.name == "anti12")
                    label6.Text = "Anti12 �sszes nyerem�nye: " + item.sum_fiz;
                //Task seven
                dataGridView1.Rows.Add(item.id, item.name, item.win);
            }
            label2.Text = $"Legnagyobb �rt�k: {max_ertek_user.name}, {max_ertek_user.db} db, {max_ertek_user.sum_win} Ft";

            //All gain of 'anti12' is 27000.

        }
        private void button1_Click(object sender, EventArgs e)
        {
            //Task two
            foreach (var item in sorsolasok)
                if (numericUpDown1.Value == stringToDecimal(item.id))
                    label1.Text = $"1. feladat: {item.id}. ID: {item.name},{item.bet},{item.factor},{item.winnerOrLoser}";
        }
    }
}