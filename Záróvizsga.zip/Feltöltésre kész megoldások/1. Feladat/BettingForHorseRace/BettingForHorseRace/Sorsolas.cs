﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BettingForHorseRace
{
    public class Sorsolas
    {
        public string id;
        public string name;
        public int bet;
        public int factor;
        public string winnerOrLoser;
        public int win;

        public Sorsolas(string id, string name, string bet, string factor, string winnerOrLoser)
        {
            this.id = id;
            this.name = name;
            this.bet = int.Parse(bet);
            this.factor = int.Parse(factor);
            this.winnerOrLoser = winnerOrLoser;
            if (winnerOrLoser == "nyertes" )
                win = this.bet * this.factor;
        }

    }
}
