﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BettingForHorseRace
{
    public class Szam
    {
        public string loser;
        public int db;

        public Szam(string loser, int db)
        {
            this.loser = loser;
            this.db = db;
        }
    }
}
