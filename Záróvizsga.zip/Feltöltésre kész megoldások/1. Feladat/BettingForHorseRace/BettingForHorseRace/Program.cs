﻿using System;

namespace BettingForHorseRace
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task one
            List<Sorsolas> sorsolas_list = new List<Sorsolas>();
            string[] lines = File.ReadAllLines("fogadasok.txt");

            foreach (var item in lines)
            {
                string[] values = item.Split(';');
                Sorsolas sorsolas_object = new Sorsolas(values[0], values[1], values[2], values[3], values[4]);
                sorsolas_list.Add(sorsolas_object);
            }

            //Task two
            Console.WriteLine("Szám 1 és 51 között: ");
            string bekert_szam = Console.ReadLine();

            foreach (var item in sorsolas_list)
            {
                if (item.id == bekert_szam)
                {
                    Console.WriteLine($"{item.id}, {item.name},  {item.bet}, {item.factor}, {item.winnerOrLoser}");
                }
            }

            //Task three
            List<Szam> szamok = new List<Szam>();

            int max = int.MinValue;
            int maximalLoss = 0;
            foreach (var item in szamok)
            {
                if (max < item.win)
                {
                    max = item.win;
                    maximalLoss = item.loser;
                }
            }
            Console.WriteLine(maximalLoss);
            //The correct result is zazu40 and the maximal loss is 100000.

            //Task four

            int db = 0;
            for (int i = 1; i < 52; i++)
            {
                foreach (var item in sorsolas_list)
                {
                    if (i == "vesztes")
                    {
                        db++;
                    }
                }
                Szam szam_object = new Szam(loser, db);
                szamok.Add(szam_object);
                db = 0;
            }
            Console.WriteLine("db");
            //The correct result is 26.

            //Task five
            max = int.MinValue;
            foreach (var item in sorsolas_list)
            {
                if (max < item.win)
                {
                    max = item.win;
                    Console.WriteLine($"{item.id}, {item.name},  {item.bet}, {item.factor}, {item.winnerOrLoser}");
                }
            }
            //The 46th betting has the maximal prize.

            //Task six
			
			if (item.StartsWith("k"))
                {
                    k_db++;
                    if (k_db < 6)
                        k_user += item + "; ";
                }

            //The only username that starts with the letter 'k' is kwestotf.

            //Task seven

            //A list of the winner bets with their username and prize.
        }
    }
}