from flask import Flask, request, json, Response
from flask_cors import CORS
import sqlite3
from hashlib import md5
from auth import is_accessible
# Python code to create a relation 
# using SQLite3
  
# import the sqlite3 package
import sqlite3  
  
# create a database named backup
cnt = sqlite3.connect("backup.dp")  
  
# create a table named beteg
cnt.execute('''CREATE TABLE beteg(
NAME TEXT,
POINTS INTEGER,
ACCURACY REAL);''')
            
# Python3 Code to insert data into
# the database
  
# Insert three tuples into the beteg table
# insert in default order
cnt.execute('''INSERT INTO beteg VALUES(
'Count Inversion',20,80.5);''')
  
# insert in different order
cnt.execute('''INSERT INTO beteg(ACCURACY, POINTS, NAME) VALUES(
90.5, 15, 'Kadanes Algo');''')
  
cnt.execute('''INSERT INTO beteg(NAME, ACCURACY, POINTS) VALUES(
'REVERSE STR', 100, 5);''')
  
# commit changes to the database
cnt.commit()

# Python3 code to read data from a table
  
print('Name, Points and Accuracy from '
      'records with accuracy greater than 85')
  
cursor = cnt.execute('''SELECT * FROM beteg WHERE ACCURACY>85;''')
  
# print data using the cursor object
for i in cursor:
    print(i[0]+"    "+str(i[1])+"   "+str(i[2]))
  
print('')  # Print new line
  
print('Name, Accuracy from '
      'records with accuracy greater than 85')
  
cursor = cnt.execute('''SELECT NAME, ACCURACY FROM
gfg WHERE ACCURACY>85;''')
  
# print data using the cursor object
for i in cursor:
    print(i[0]+"    "+str(i[1]))

# Python3 code to update records in a database
  
# Print records before updation
cursor = cnt.execute('''SELECT * FROM beteg''')
print('Before Updation')
for i in cursor:
    print(i[0]+"    "+str(i[1])+"    "+str(i[2]))
  
print('')  # print a newline
  
# Execute an Update statement
cnt.execute('''UPDATE beteg SET POINTS=POINTS+5 WHERE
POINTS<20;''')
  
cursor = cnt.execute('''SELECT * FROM beteg''')
print('After Updation')
for i in cursor:
    print(i[0]+"    "+str(i[1])+"    "+str(i[2]))

# Python3 code to delete records from database
  
# Print records before deletion
cursor = cnt.execute('''SELECT * FROM beteg''')
print('Before Deletion')
for i in cursor:
    print(i[0]+"    "+str(i[1])+"    "+str(i[2]))
  
print('')  # print a newline
  
# Execute a delete statement
cnt.execute('''DELETE FROM beteg WHERE ACCURACY>91;''')
  
cursor = cnt.execute('''SELECT * FROM beteg''')
print('After Deletion')
for i in cursor:
    print(i[0]+"    "+str(i[1])+"    "+str(i[2]))

api = Flask(__name__)
CORS(api, origins=['http://localhost:8000', 'http://localhost:3000'], methods=['GET', 'POST'])
# api.config['CORS_HEADERS'] = 'Content-Type'

@api.route('/users/login', methods=['POST'])
def get_token():
    data = request.json
    con = sqlite3.connect('data.db')
    con.row_factory = sqlite3.Row     # needed for using keys() later
    cur = con.cursor()
    cur.execute('SELECT id, token FROM users WHERE email = ? AND password = ?', (data['email'], md5(data['password'].encode('UTF-8')).hexdigest()))
    row = cur.fetchone()
    user = dict(zip(row.keys(), row))
    return json.dumps(user)


@api.route('/users')
def get_users():
    if not is_accessible():
        return Response('Access denied', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    con = sqlite3.connect('data.db')
    con.row_factory = sqlite3.Row     # needed for using keys() later
    cur = con.cursor()
    cur.execute('SELECT * FROM users')
    rows = cur.fetchall()
    users = []
    for row in rows:
        d = dict(zip(row.keys(), row))   # a dict with column names as keys
        users.append(d)
    return json.dumps(users)


@api.route('/products', methods=['GET', 'POST'])             # default is GET
def get_products():
    if not is_accessible():
        return Response('Access denied', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    con = sqlite3.connect('data.db')
    con.row_factory = sqlite3.Row     # needed for using keys() later
    cur = con.cursor()

if __name__ == '__main__':
    api.run(debug=True) # TODO remove in production